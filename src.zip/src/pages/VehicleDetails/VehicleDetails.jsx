import { useState, useEffect } from "react";
import "./VehicleDetails.css";

const VEHICLE_DATABASE = {
  "mclaren-750s": {
    id: "mclaren-750s",
    name: "750S SPIDER",
    brand: "McLaren",
    series: "SUPER SERIES",
    price: "$337,195",
    image: "./cars/mclaren-3.jpeg",
    images: {
      hero: "./cars/mclaren-3.jpeg",
      overview: "./cars/mclaren-3.jpeg",
      lightness: "./cars/mclaren-1.jpg",
      engagement: "./cars/mclaren-4.jpeg",
      power: "./cars/mclaren-12.jpg",
      specification: "./cars/mclaren-2.jpg",
    },
    performance: {
      horsepower: "750 PS / 740 HP",
      topSpeed: "332 km/h / 206 MPH",
      torque: "800 Nm / 590 lb-ft",
      acceleration0100: "2.8s",
      acceleration0200: "7.2s",
      engine: "M840T 4.0L Twin-Turbocharged V8",
      weight: "1,281 kg",
      transmission: "7-Speed Dual-Clutch SSG",
      chassis: "Carbon Fibre Monocage II",
      brakes: "Carbon Ceramic Discs (390mm / 380mm)",
    },
    overviewHeadline: "RELENTLESS PROGRESS. MORE POWER. MORE CONTROL.",
    overviewText:
      "The 750S takes the McLaren ethos to a new apex. True to its DNA, it's the next-level supercar, surpassing benchmarks for performance.",
    lightnessHeadline: "LIGHTWEIGHT COMPOSITE PURSUIT",
    lightnessText:
      "30% of components are new or revised compared to the 720S, resulting in an overall 30kg weight reduction.",
    engagementHeadline: "SURGICAL STEERING & PROACTIVE CHASSIS CONTROL III",
    engagementText:
      "Features a 6mm wider front track, twin-valve hydraulic dampers, and a faster steering rack ratio.",
    powerHeadline: "MID-MOUNTED 4.0L TWIN-TURBO V8 ENGINE",
    powerText:
      "At the heart of the 750S is a 4-litre twin-turbocharged V8 engine mid-mounted for perfect weight distribution.",
  },
  "mclaren-720s": {
    id: "mclaren-720s",
    name: "720S SPIDER",
    brand: "McLaren",
    series: "SUPER SERIES",
    price: "$315,000",
    image: "./cars/mclaren-1.jpg",
    images: {
      hero: "./cars/mclaren-1.jpg",
      overview: "./cars/mclaren-1.jpg",
      lightness: "./cars/mclaren-2.jpg",
      engagement: "./cars/mclaren-4.jpeg",
      power: "./cars/mclaren-12.jpg",
      specification: "./cars/mclaren-3.jpeg",
    },
    performance: {
      horsepower: "710 PS / 700 HP",
      topSpeed: "341 km/h / 212 MPH",
      torque: "770 Nm / 568 lb-ft",
      acceleration0100: "2.9s",
      acceleration0200: "7.9s",
      engine: "M840T 4.0L Twin-Turbo V8",
      weight: "1,332 kg",
      transmission: "7-Speed Dual-Clutch SSG",
      chassis: "Carbon Fibre Monocage II-S",
      brakes: "Carbon Ceramic Discs (390mm / 380mm)",
    },
    overviewHeadline: "BENCHMARK PERFORMANCE & OPEN-TOP FEROCITY",
    overviewText:
      "The McLaren 720S Spider is the culmination of our pursuit to push the boundaries of open-top supercar performance.",
    lightnessHeadline: "CARBON FIBRE MONOCAGE II-S ARCHITECTURE",
    lightnessText:
      "Derived from Formula 1 composite technology, it provides immense structural rigidity.",
    engagementHeadline: "SURGICAL HYDRAULIC STEERING FEEDBACK",
    engagementText:
      "Electro-hydraulic steering provides pure, unassisted dynamic feel.",
    powerHeadline: "FEROCIOUS 710 HP TWIN-TURBOCHARGED V8",
    powerText:
      "Generating 710 HP and 770 Nm of torque, propels from 0 to 200 km/h in 7.9 seconds.",
  },
};

function resolveVehicleData(id) {
  if (!id) return VEHICLE_DATABASE["mclaren-750s"];
  if (VEHICLE_DATABASE[id]) return VEHICLE_DATABASE[id];
  const lower = id.toLowerCase();
  if (lower.includes("720")) return VEHICLE_DATABASE["mclaren-720s"];
  return VEHICLE_DATABASE["mclaren-750s"];
}

export default function VehicleDetails({ carId }) {
  const [vehicle, setVehicle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] = useState("overview");

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [deliveryRegion, setDeliveryRegion] = useState("North America");
  const [exteriorColor, setExteriorColor] = useState("Signature Papaya Spark");
  const [additionalNotes, setAdditionalNotes] = useState("");
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    async function loadVehicle() {
      setLoading(true);
      try {
        if (carId) {
          const res = await fetch(
            `http://localhost:3000/api/vehicles/${carId}`,
          );
          if (res.ok) {
            const data = await res.json();
            setVehicle(data);
            setLoading(false);
            return;
          }
        }
      } catch (err) {
        console.warn("Express API fetch note, loading local fallback: ", err);
      }

      setVehicle(resolveVehicleData(carId));
      setLoading(false);
    }

    loadVehicle();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [carId]);

  const handlePurchaseSubmit = async (e) => {
    e.preventDefault();
    if (!agreedToTerms) return;

    try {
      const response = await fetch(
        "http://localhost:3000/api/purchase_requests",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            clientName,
            clientEmail,
            vehicleName: vehicle.name,
            carModel: vehicle.id,
            deliveryRegion,
            exteriorColor,
            additionalNotes,
            status: "Pending Review",
          }),
        },
      );

      if (response.ok) {
        setSubmitted(true);
      } else {
        alert("Failed to submit purchase request.");
      }
    } catch (err) {
      console.error("Error saving purchase request:", err);
      alert("Error connecting to http://localhost:3000");
    }
  };

  const resetModal = () => {
    setSubmitted(false);
    setIsModalOpen(false);
    setClientName("");
    setClientEmail("");
    setDeliveryRegion("North America");
    setExteriorColor("Signature Papaya Spark");
    setAdditionalNotes("");
    setAgreedToTerms(false);
  };

  if (loading || !vehicle) {
    return (
      <div className="details-loading">
        <div className="details-spinner" aria-hidden="true" />
        <span>LOADING McLAREN SPECIFICATIONS...</span>
      </div>
    );
  }

  const heroImg = vehicle?.images?.hero || vehicle?.image;

  return (
    <div className="arch-editorial-page">
      <section
        className="arch-hero"
        style={{ backgroundImage: `url(${heroImg})` }}
      >
        <div className="arch-hero-tint" />
        <div className="arch-hero-text">
          <span className="brand-prefix">{vehicle.brand || "McLaren"}</span>
          <h1 className="hero-car-title">{vehicle.name}</h1>
        </div>
      </section>

      <nav className="arch-subnav">
        <div className="subnav-container">
          <button
            className="single-purchase-btn"
            onClick={() => setIsModalOpen(true)}
          >
            PURCHASE REQUEST →
          </button>
        </div>
      </nav>

      {isModalOpen && (
        <div className="modal-overlay" onClick={() => setIsModalOpen(false)}>
          <div className="modal-container" onClick={(e) => e.stopPropagation()}>
            <button
              className="modal-close-btn"
              onClick={() => setIsModalOpen(false)}
            >
              ✕
            </button>

            <h2>PURCHASE REQUEST: {vehicle.name}</h2>
            <p className="modal-subtitle">Starting Price: {vehicle.price}</p>

            {submitted ? (
              <div className="modal-success">
                <span className="check-mark">✓</span>
                <h3>PURCHASE REQUEST RECEIVED</h3>
                <p>
                  Thank you, <strong>{clientName}</strong>. A McLaren Specialist
                  will contact you at <strong>{clientEmail}</strong>.
                </p>
                <button className="modal-submit-btn" onClick={resetModal}>
                  Close Window
                </button>
              </div>
            ) : (
              <form onSubmit={handlePurchaseSubmit} className="modal-form">
                <div className="modal-field">
                  <label>Full Name *</label>
                  <input
                    type="text"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    required
                  />
                </div>

                <div className="modal-field">
                  <label>Email Address *</label>
                  <input
                    type="email"
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    required
                  />
                </div>

                <div className="modal-field">
                  <label>Delivery Region *</label>
                  <select
                    value={deliveryRegion}
                    onChange={(e) => setDeliveryRegion(e.target.value)}
                  >
                    <option value="North America">North America</option>
                    <option value="Europe / UK">Europe / UK</option>
                    <option value="Middle East">Middle East</option>
                    <option value="Asia Pacific">Asia Pacific</option>
                  </select>
                </div>

                <label className="modal-checkbox-row">
                  <input
                    type="checkbox"
                    checked={agreedToTerms}
                    onChange={(e) => setAgreedToTerms(e.target.checked)}
                    required
                  />
                  <span>I agree to the Terms &amp; Conditions.</span>
                </label>

                <button
                  type="submit"
                  className="modal-submit-btn"
                  disabled={!agreedToTerms}
                >
                  Submit Purchase Request →
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

import { useState, useEffect } from "react";

// Layout Components
import Header from "./component/Header/Header";
import Footer from "./component/Footer/Footer";

// Pages & Views
import Home from "./pages/Home/Home";
import Models from "./pages/Models/Models";
import VehicleDetails from "./pages/VehicleDetails/VehicleDetails";
import About from "./pages/About/About";
import Contact from "./pages/Contact/Contact";
import Account from "./component/Account/Account";
import Messages from "./pages/Messages/Messages";
import Login from "./pages/Login/Login";
import SignUp from "./pages/Login/SignUp";
import ForgotPassword from "./component/Account/ForgotPassword";
import AdminDashboard from "./component/Admin/AdminDashboard";

import "./App.css";

const API_BASE = "http://localhost:3000/api";

function App() {
  const [currentPage, setCurrentPage] = useState("home");
  const [selectedVehicleId, setSelectedVehicleId] = useState(null);
  const [user, setUser] = useState({
    isLoggedIn: false,
    uid: null,
    name: "",
    email: "",
  });
  const [authChecked, setAuthChecked] = useState(false);

  // Restore session from stored token on load
  useEffect(() => {
    async function restoreSession() {
      const token = localStorage.getItem("token");
      if (!token) {
        setAuthChecked(true);
        return;
      }
      try {
        const res = await fetch(`${API_BASE}/auth/me`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          setUser({
            isLoggedIn: true,
            uid: data.user.id,
            name: data.user.name,
            email: data.user.email,
          });
        } else {
          localStorage.removeItem("token");
        }
      } catch (err) {
        console.warn("Could not restore session:", err.message);
      } finally {
        setAuthChecked(true);
      }
    }
    restoreSession();
  }, []);

  const navigateTo = (page, vehicleId = null) => {
    setCurrentPage(page);
    if (vehicleId) {
      setSelectedVehicleId(vehicleId);
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const hideFooterPages = ["login", "signup", "forgot-password", "admin"];

  if (!authChecked) {
    return null; // avoids a Login->Account flash while session restores
  }

  return (
    <div className="app-frame">
      <Header currentPage={currentPage} navigateTo={navigateTo} user={user} />

      <main className="view-window">
        {currentPage === "home" && <Home navigateTo={navigateTo} />}

        {currentPage === "models" && <Models navigateTo={navigateTo} />}

        {currentPage === "vehicle-details" && (
          <VehicleDetails carId={selectedVehicleId} navigateTo={navigateTo} />
        )}

        {currentPage === "about" && <About navigateTo={navigateTo} />}

        {currentPage === "contact" && <Contact navigateTo={navigateTo} />}

        {currentPage === "login" && (
          <Login navigateTo={navigateTo} setUser={setUser} />
        )}

        {currentPage === "signup" && (
          <SignUp navigateTo={navigateTo} setUser={setUser} />
        )}

        {currentPage === "forgot-password" && (
          <ForgotPassword onBackToLogin={() => navigateTo("login")} />
        )}

        {currentPage === "account" && (
          <Account user={user} setUser={setUser} navigateTo={navigateTo} />
        )}
        {currentPage === "messages" && (
          <Messages user={user} navigateTo={navigateTo} />
        )}

        {currentPage === "admin" && <AdminDashboard navigateTo={navigateTo} />}
      </main>

      {!hideFooterPages.includes(currentPage) && (
        <Footer navigateTo={navigateTo} />
      )}
    </div>
  );
}

export default App;
